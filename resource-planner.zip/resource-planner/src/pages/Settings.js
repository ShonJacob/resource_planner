import React from 'react'

const Settings = () => {
    return (
        <div>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam perspiciatis quam repellendus cum alias quod cupiditate voluptates soluta illo consectetur. Sed aliquid ullam est, voluptatem ex necessitatibus nulla fugiat repudiandae.
        </div>
    )
}

export default Settings
