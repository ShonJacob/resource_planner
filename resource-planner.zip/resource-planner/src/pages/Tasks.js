import React from 'react'

const Tasks = () => {
    return (
        <div>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex voluptates doloribus, adipisci pariatur nostrum optio beatae nesciunt accusantium expedita officiis inventore nisi perferendis molestias necessitatibus vero similique sunt exercitationem cum!
        </div>
    )
}

export default Tasks
